package ljc.controller.dto;

import lombok.Data;

@Data
public class LoginReq {
    private String username;
    private String password;
}
