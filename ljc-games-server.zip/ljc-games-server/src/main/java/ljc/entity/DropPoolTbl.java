package ljc.entity;

import lombok.Data;

@Data
public class DropPoolTbl {
    private Integer poolId;
    private String entriesJson;
}
