package ljc.entity;

import lombok.Data;

@Data
public class SkillBookMapTbl {
    private Integer itemId;
    private Integer skillId;
}
